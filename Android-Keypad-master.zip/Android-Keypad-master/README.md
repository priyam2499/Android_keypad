# Android-Keypad
The working of this project is same as the android keypad.
